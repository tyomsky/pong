package com.codenjoy.dojo.sample.client;

import com.codenjoy.dojo.client.AbstractBoard;
import com.codenjoy.dojo.sample.model.Elements;
import com.codenjoy.dojo.services.Point;

import java.util.List;

/**
 * Класс, обрабатывающий строковое представление доски.
 * Содержит ряд унаследованных методов {@see AbstractBoard},
 * но ты можешь добавить сюда любые свои методы на их основе.
 */

public class Board extends AbstractBoard<Elements> {

    @Override
    public Elements valueOf(char ch) {
        return Elements.valueOf(ch);
    }

    public List<Point> getMe() {
        return get(Elements.HERO);
    }

    public Point getBall() {
        List<Point> balls = get(Elements.BALL);
        if (!balls.isEmpty()) {
            return balls.get(0);
        } else {
            return null;
        }

    }

}